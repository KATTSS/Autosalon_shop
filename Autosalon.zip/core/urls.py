from django.urls import path, re_path
from . import views

app_name = 'core'

urlpatterns = [
    # Главная страница
    path('', views.HomeView.as_view(), name='home'),
    
    # О компании
    path('about/', views.AboutView.as_view(), name='about'),
    
    # Контакты
    path('contacts/', views.ContactsView.as_view(), name='contacts'),
    
    # Политика конфиденциальности
    path('privacy/', views.PrivacyView.as_view(), name='privacy'),
    
    # Каталог товаров
    path('catalog/', views.ProductListView.as_view(), name='catalog'),
    re_path(r'^catalog/(?P<pk>\d+)/$', views.ProductDetailView.as_view(), name='product_detail'),
    # path('catalog/<int:pk>/', views.ProductDetailView.as_view(), name='product_detail'),

    # Корзина
    path('cart/', views.CartView.as_view(), name='cart'),
    re_path(r'^cart/add/(?P<product_id>\d+)/$', views.add_to_cart, name='add_to_cart'),
    re_path(r'^cart/remove/(?P<item_id>\d+)/$', views.remove_from_cart, name='remove_from_cart'),
    re_path(r'^cart/update/(?P<product_id>\d+)/$', views.update_cart, name='update_cart'),
    # path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    # path('cart/remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    # path('cart/update/<int:product_id>/', views.update_cart, name='update_cart'),
    
    # Оформление заказа
    path('checkout/', views.CheckoutView.as_view(), name='checkout'),
    
    # Личный кабинет
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('profile/orders/', views.OrderHistoryView.as_view(), name='order_history'),
    path('profile/edit/', views.ProfileUpdateView.as_view(), name='profile_edit'),
    
    # Авторизация
    path('login/', views.LoginView.as_view(), name='login'),
    path('logout/', views.LogoutView.as_view(), name='logout'),
    path('register/', views.RegisterView.as_view(), name='register'),

    # Календарь
    path('datetime/', views.DateTimeDemoView.as_view(), name='datetime_demo'),
    path('set-timezone/', views.set_timezone, name='set_timezone'),

    # Статистика
    path('statistics/', views.StatisticsView.as_view(), name='statistics'),
]